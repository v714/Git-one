package com.example.campus_catering;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import android.content.res.Resources;

public class Carthelperdrinks {

public static final String PRODUCT_INDEX = "PRODUCT_INDEX";
	
	private static List<Product> catalog;
	private static Map<Product, Shoppingcartentry> 
	cartMap = new HashMap<Product, Shoppingcartentry>();
	
	
	
	public static List<Product> getCatalog(Resources res) {
		
		if (catalog==null)
		{
			catalog = new Vector<Product>();
			
			catalog.add(new Product("Tea Cardamom",res.getDrawable(R.drawable.tea), 
					"", 10));
			
			catalog.add(new Product("Coffee",res.getDrawable(R.drawable.tea), 
					"", 10));
			
			catalog.add(new Product("Milk Badam ",res.getDrawable(R.drawable.milk), 
					"300 Ml", 35));
			
			catalog.add(new Product("Milk Pista",res.getDrawable(R.drawable.milk), 
					"300 Ml", 40));
			
			catalog.add(new Product("Milk Kesar",res.getDrawable(R.drawable.milk), 
					"", 35));
			
			catalog.add(new Product("Milk Vanilla",res.getDrawable(R.drawable.milk), 
					"", 35));
			
			catalog.add(new Product("Orange Juice",res.getDrawable(R.drawable.drink), 
					"", 35));
			
			catalog.add(new Product("Mix Fruit Juice",res.getDrawable(R.drawable.drink), 
					"", 35));
			
			catalog.add(new Product("Pineapple Juice",res.getDrawable(R.drawable.drink), 
					"", 35));
			
			catalog.add(new Product("Carrot Juice",res.getDrawable(R.drawable.drink), 
					"", 35));
			
			catalog.add(new Product("Banana Shake",res.getDrawable(R.drawable.drink), 
					"", 25));
			
			catalog.add(new Product("Mango Shake",res.getDrawable(R.drawable.drink), 
					"", 25));
			
			catalog.add(new Product("Strawberry Shake",res.getDrawable(R.drawable.drink), 
					"", 25));
			
			catalog.add(new Product("Chocolate Shake",res.getDrawable(R.drawable.drink), 
					"", 25));
			
			catalog.add(new Product("Papaya Shake",res.getDrawable(R.drawable.drink), 
					"", 25));
			
			catalog.add(new Product("Soft Drink Coca-Cola",res.getDrawable(R.drawable.cdrink), 
					"", 30));
			
			catalog.add(new Product("Soft Drink Pepsi",res.getDrawable(R.drawable.cdrink), 
					"", 30));
			
			catalog.add(new Product("Soft Drink Fanta",res.getDrawable(R.drawable.cdrink), 
					"", 30));
			
			catalog.add(new Product("Maaza Packaged Juice",res.getDrawable(R.drawable.drink), 
					"", 20));
			
			catalog.add(new Product("Soft Drink Sprite",res.getDrawable(R.drawable.cdrink), 
					"", 30));
			
			
			
		}
		
		return catalog;
	}
	public static void setQuantity(Product product, int quantity) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		// If the quantity is zero or less, remove the products
		if(quantity <= 0) {
			if(curEntry != null)
				removeProduct(product);
			return;
		}
		
		// If a current cart entry doesn't exist, create one
		if(curEntry == null) {
			curEntry = new Shoppingcartentry(product, quantity);
			cartMap.put(product, curEntry);
			return;
		}
		
		// Update the quantity
		curEntry.setQuantity(quantity);
	}
	
	public static int getProductQuantity(Product product) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		if(curEntry != null)
			return curEntry.getQuantity();
		
		return 0;
	}
	
	public static void removeProduct(Product product) {
		cartMap.remove(product);
	}
	
	public static List<Product> getCartList() {
		List<Product> cartList = new Vector<Product>(cartMap.keySet().size());
		for(Product p : cartMap.keySet()) {
			cartList.add(p);
		}
		
		return cartList;
	}
	}


