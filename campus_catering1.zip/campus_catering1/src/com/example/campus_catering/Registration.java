package com.example.campus_catering;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class Registration extends Activity {
	
	
	
	EditText pas;
	EditText fpas;
	EditText phint;
	
	
	Button save;
	LoginDatabaseAdapter log;


	@Override
    protected void onCreate(Bundle savedInstanceState) 
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        getActionBar().setIcon(
     		   new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        
       log = new LoginDatabaseAdapter(this);
       log = log.open();
       
        
       
        pas = (EditText) findViewById(R.id.editText2);
        fpas = (EditText) findViewById(R.id.editText3);
        phint = (EditText) findViewById(R.id.editText4);
        
       
        save = (Button) findViewById(R.id.button1);
        
        
        
        save.setOnClickListener(new View.OnClickListener()
        {
        	
        	
        	
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				String Pass=pas.getText().toString();
				String Secu=phint.getText().toString();
				String Repass=fpas.getText().toString();
				
				if(Pass.equals("")||Repass.equals("")||Secu.equals(""))
				{
						Toast.makeText(getApplicationContext(), "Fill All Fields", Toast.LENGTH_LONG).show();
						return;
				}
				
				if(!Pass.equals(Repass))
				{
					Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_LONG).show();
					return;
				}
				else
				{
				    // Save the Data in Database
				    log.insertEntry(Pass, Repass,Secu);
				   
				   // reg_btn.setVisibility(View.GONE);
				    Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_SHORT).show();
				    Log.d("PASSWORD",Pass);
				    Log.d("RE PASSWORD",Repass);
				    Log.d("SECURITY HINT",Secu);
				    
				    Intent i=new Intent(Registration.this,MainActivity.class);
				   	startActivity(i);
				    
				 }
		};
        
        
        
	
        });
	}
	
}

	
	

