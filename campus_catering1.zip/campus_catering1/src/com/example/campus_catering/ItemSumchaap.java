package com.example.campus_catering;

import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class ItemSumchaap extends Activity {

	private List<Product> mproductlist;
	ListView lv;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.itemsum);
		getActionBar().setIcon(
     		   new ColorDrawable(getResources().getColor(android.R.color.transparent))); 
	
		mproductlist = Carthelperchaap.getCatalog(getResources());
		lv= (ListView) findViewById(R.id.menu_list);
		lv.setAdapter(new ProductAdapter(mproductlist,getLayoutInflater(),false));
		
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,long id) 
			{
				Intent i = new Intent(getBaseContext(),Itemdetailschaap.class);
				i.putExtra(Carthelperchaap.PRODUCT_INDEX, position);
				startActivity(i);
			}
		});
		
		Button b = (Button) findViewById(R.id.button1);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			Intent i = new Intent(getBaseContext(),Cartactivitychaap.class);
			startActivity(i);
				
			}
		});

		
		
	
	
	}
	

}
