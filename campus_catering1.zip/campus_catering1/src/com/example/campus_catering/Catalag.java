package com.example.campus_catering;

import android.app.Activity;
import android.app.LauncherActivity.ListItem;
import android.content.ClipData.Item;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Catalag extends Activity {
	
	String[] categories = new String[]
			{
			"North Indian",
			"South Indian",
			"Fast Food",
			"Kababs And Chaap",
			"Desserts",
			"Refreshment"
			
			};

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
	super.onCreate(savedInstanceState);
	setContentView(R.layout.catalag);
	
	ListView l = (ListView) findViewById(R.id.list_view);
	
	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,categories);
	l.setAdapter(adapter);
	
	
	l.setOnItemClickListener(new OnItemClickListener() {
	
	

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			// TODO Auto-generated method stub
			Intent intent;
	        switch (position) {
	            case 0:
	                intent= new Intent(Catalag.this,ItemSum.class);
	                startActivity(intent);
	                break;
	            case 1:
	                intent=new Intent(Catalag.this,ItemSumsouth.class);
	                startActivity(intent);
	                break;
	            case 2:
	                intent=new Intent(Catalag.this,ItemSumfast.class);
	                startActivity(intent);  
	                break;
	            case 3:
	                intent=new Intent(Catalag.this,ItemSumchaap.class);
	                startActivity(intent);      
	                break;
	            case 4:
	                intent=new Intent(Catalag.this,ItemSumdessert.class);
	                startActivity(intent);          
	                break;
	            case 5:
	                intent=new Intent(Catalag.this,ItemSumdrinks.class);
	                startActivity(intent);          
	                break;  
	            default:
	                break;
	        }       
		}
		
	});
	}
	
	
	}
	

