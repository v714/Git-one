package com.example.campus_catering;

import android.app.Activity;
import android.content.Intent;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import android.view.View;
import android.widget.ImageView;

public class Frontpage extends Activity{
	
	
	ImageView t;

	
	
	

	
	@Override
	   protected void onCreate(Bundle savedInstanceState) {
	      super.onCreate(savedInstanceState);
	      
	      setContentView(R.layout.frontpage);
	      getActionBar().setIcon( new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		     
	t = (ImageView) findViewById(R.id.imageView2);
	t.setOnClickListener(new View.OnClickListener()
	{ 
		
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			Intent i=new Intent(Frontpage.this,Category.class)	;
			startActivity(i);
			
			finish();
		}
	});
	
	
	}

}

