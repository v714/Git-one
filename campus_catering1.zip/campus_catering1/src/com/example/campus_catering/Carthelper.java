package com.example.campus_catering;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import android.content.res.Resources;

public class Carthelper {

public static final String PRODUCT_INDEX = "PRODUCT_INDEX";
	
	private static List<Product> catalog;
	private static Map<Product, Shoppingcartentry> 
	cartMap = new HashMap<Product, Shoppingcartentry>();
	
	
	
	public static List<Product> getCatalog(Resources res) {
		
		if (catalog==null)
		{
			catalog = new Vector<Product>();
			catalog.add(new Product("Aaloo Parantha",res.getDrawable(R.drawable.dish1), 
					"Aaloo Parantha With Curd or Pickle", 35));
			
			catalog.add(new Product("Mooli Parantha",res.getDrawable(R.drawable.dish1), 
					"Mooli Parantha With Curd or Pickle", 35));
			
			catalog.add(new Product("Gobhi Parantha",res.getDrawable(R.drawable.dish1), 
					"Gobhi Parantha With Curd or Pickle", 35));
			
			catalog.add(new Product("Onion Parantha",res.getDrawable(R.drawable.dish1), 
					"Onion Parantha With Curd or Pickle", 35));
			
			catalog.add(new Product("Paneer Parantha",res.getDrawable(R.drawable.dish1), 
					"Paneer Parantha With Curd or Pickle", 45));
			
			catalog.add(new Product("Dal Parantha",res.getDrawable(R.drawable.dish1), 
					"Moong Dal filling With Curd or Pickle", 35));
			
			
			catalog.add(new Product("Rajma Rice",res.getDrawable(R.drawable.dish1), 
					"North Indian Rajma Dish With Rice or Chapati", 25));
			
			catalog.add(new Product("Chana Rice",res.getDrawable(R.drawable.dish1), 
					"Chana Rice with Curd or Pickle", 25));
			
			catalog.add(new Product("Dal Rice",res.getDrawable(R.drawable.dish1), 
					"North Indian Dal Makhni with rice + Curd or Pickle", 25));
			
			catalog.add(new Product("Kadhi Rice",res.getDrawable(R.drawable.dish1), 
					"Kadhi Rice With Salad,Pickle", 25));
			
			catalog.add(new Product("Palak Paneer",res.getDrawable(R.drawable.dish1), 
					"1 Palak Paneer Dish with Rice or Tandoor Roti + Curd + Salad", 30));
			
			catalog.add(new Product("Shahi Paneer",res.getDrawable(R.drawable.dish1), 
					"1 Shahi Paneer Dish with Rice or Chapati + Curd + Salad", 30));
			
			catalog.add(new Product("Chana Bhatura Thali",res.getDrawable(R.drawable.dish1), 
					"2 Pc + Chana /Aaloo + Curd + Salad +Pickle", 25));
			
			catalog.add(new Product("North Indian Thali",res.getDrawable(R.drawable.dish1), 
					"Dal + Sabzi + Curd Raita + Chapati/Tandoor Roti + Pickle", 40));
			
			catalog.add(new Product("Rumali Roti",res.getDrawable(R.drawable.dish1), 
					"Thin Flat bread (Min Quantity 5", 7));
			
			catalog.add(new Product("Tandoori Roti",res.getDrawable(R.drawable.dish1), 
					" Made with Wholewheat flour inside Clay Over(Tandoor)  ", 7));
			
			catalog.add(new Product("Paneer Naan",res.getDrawable(R.drawable.dish1), 
					"Flavoured stuffed Naan with a filling of Paneer", 60));
			
			
		}
		
		return catalog;
	}
	public static void setQuantity(Product product, int quantity) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		// If the quantity is zero or less, remove the products
		if(quantity <= 0) {
			if(curEntry != null)
				removeProduct(product);
			return;
		}
		
		// If a current cart entry doesn't exist, create one
		if(curEntry == null) {
			curEntry = new Shoppingcartentry(product, quantity);
			cartMap.put(product, curEntry);
			return;
		}
		
		// Update the quantity
		curEntry.setQuantity(quantity);
	}
	
	public static int getProductQuantity(Product product) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		if(curEntry != null)
			return curEntry.getQuantity();
		
		return 0;
	}
	
	public static void removeProduct(Product product) {
		cartMap.remove(product);
	}
	
	public static List<Product> getCartList() {
		List<Product> cartList = new Vector<Product>(cartMap.keySet().size());
		for(Product p : cartMap.keySet()) {
			cartList.add(p);
		}
		
		return cartList;
	}
	}


