package com.example.campus_catering;
import java.util.List;


import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Itemdetailsfast extends Activity{
	

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.productdetails);
		getActionBar().setIcon( new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		List<Product> catalog = Carthelperfast.getCatalog(getResources());
		
		int productIndex = getIntent().getExtras().getInt(Carthelperfast.PRODUCT_INDEX);
		final Product selectedProduct = catalog.get(productIndex);
		
		ImageView iv = (ImageView) findViewById(R.id.imageView1);
		iv.setImageDrawable(selectedProduct.productImage);
		TextView tv = (TextView) findViewById(R.id.textView1);
		tv.setText(selectedProduct.title);
		TextView dtv= (TextView) findViewById(R.id.textView2);
		dtv.setText(selectedProduct.description);
		TextView productPriceTextView = (TextView) findViewById(R.id.TextViewProductPrice);
		  productPriceTextView.setText(" Rs" + selectedProduct.price);
		  
		
		// Save a reference to the quantity edit text
		final EditText editTextQuantity = (EditText) findViewById(R.id.editTextQuantity);





Button b = (Button) findViewById(R.id.button1);

b.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
	
		// Check to see that a valid quantity was entered
		int quantity = 0;
		try {
			quantity = Integer.parseInt(editTextQuantity.getText().toString());

			if (quantity < 0 ) 
			{
				Toast.makeText(getBaseContext(),
						"Please enter a quantity of 0 or higher",
						Toast.LENGTH_SHORT).show();
				return;
			}

		} catch (Exception e) 
		{
			Toast.makeText(getBaseContext(),"Please enter a numeric quantity",Toast.LENGTH_SHORT).show();

			return;
		}

		// If we make it here, a valid quantity was entered
		Carthelperfast.setQuantity(selectedProduct, quantity);

		// Close the activity
		finish();
	}
});

}
}
