package com.example.campus_catering;



import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Category extends Activity{

	
	TextView t;
	TextView t1;
	TextView t2;
	TextView t3;
	TextView t4;
	TextView t5;
	
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.category);
		getActionBar().setIcon( new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		this.overridePendingTransition(R.anim.animation_enter,R.anim.animation_leave);
		
		 t= (TextView) findViewById(R.id.textView1);
	
	      
		 t1=(TextView) findViewById(R.id.textView2);
	
	      
	     t2=(TextView) findViewById(R.id.textView3);
	 
	     t3=(TextView) findViewById(R.id.textView4);
	  
	     
	     t4=(TextView) findViewById(R.id.textView5);
	  
	     
	     t5=(TextView) findViewById(R.id.textView6);
	  
	     
		
		t.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			
				
				Intent i= new Intent(getBaseContext(),ItemSum.class);
				startActivity(i);
				
			}
		});
		
		t1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i= new Intent(getBaseContext(),ItemSumsouth.class);
				startActivity(i);
				
			}
		});
		
		t2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i= new Intent (getBaseContext(),ItemSumfast.class);
				startActivity(i);
				
			}
		});
		
			t3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			
				
				Intent i= new Intent(getBaseContext(),ItemSumchaap.class);
				startActivity(i);
				
			}
		});

				t4.setOnClickListener(new View.OnClickListener() {
	
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
	
		
							Intent i= new Intent(getBaseContext(),ItemSumdessert.class);
							startActivity(i);
		
					}
				});

					t5.setOnClickListener(new View.OnClickListener() {
	
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
	
		
							Intent i= new Intent(getBaseContext(),ItemSumdrinks.class);
							startActivity(i);
		
						}
					});
	}
	
		
					
	
	
	
}
