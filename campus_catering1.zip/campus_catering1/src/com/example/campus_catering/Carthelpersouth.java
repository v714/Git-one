package com.example.campus_catering;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import android.content.res.Resources;

public class Carthelpersouth {

public static final String PRODUCT_INDEX = "PRODUCT_INDEX";
	
	private static List<Product> catalog;
	private static Map<Product, Shoppingcartentry> 
	cartMap = new HashMap<Product, Shoppingcartentry>();
	
	
	
	public static List<Product> getCatalog(Resources res) {
		
		if (catalog==null)
		{
			catalog = new Vector<Product>();
			catalog.add(new Product("Butter Masala Dosa",res.getDrawable(R.drawable.dish1), 
					"Dosa stuffed with light coocked Potatoes,Onion,Green Chilli,Spices", 40));
			
			catalog.add(new Product("Onion Masala Dosa",res.getDrawable(R.drawable.dish1), 
					"Dosa wrapped around Onion and Potato Curry or Masala", 40));
			
			catalog.add(new Product("Butter Plain Dosa",res.getDrawable(R.drawable.dish1), 
					"Dosa made with Butter/Ghee with Chutney", 30));
			
			catalog.add(new Product("Butter Paneer Dosa",res.getDrawable(R.drawable.dish1), 
					"Crisp Dosa with Paneer Butter Masala filling", 50));
			
			catalog.add(new Product("Butter Plain Uttapam",res.getDrawable(R.drawable.dish1), 
					"Uttapam with filling  with butter spread", 30));
			
			catalog.add(new Product("Onion Uttapam",res.getDrawable(R.drawable.dish1), 
					"Simple Onion Uttapam with Coconut chutney", 35));
			
			catalog.add(new Product("Mix Uttapam",res.getDrawable(R.drawable.dish1), 
					"Uttapam with stuffed Veggies  + Curd/Chutney", 35));
			
			catalog.add(new Product("Tomato Uttapam",res.getDrawable(R.drawable.dish1), 
					"Uttapam Topped with Chopped Tomatoes and Onion", 35));
			
			catalog.add(new Product("Idli Sambar",res.getDrawable(R.drawable.dish1), 
					"Idli with Sambar or Coconut Chutney", 25));
			
			catalog.add(new Product("Dahi Vada",res.getDrawable(R.drawable.dish1), 
					"Indian Chaat made by soaking vada in thick dahi", 30));
			
			catalog.add(new Product("Vada Sambar",res.getDrawable(R.drawable.dish1), 
					"Puffy Dal Vada dipped in hot Sambar", 30));
			
			
			
		}
		
		return catalog;
	}
	public static void setQuantity(Product product, int quantity) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		// If the quantity is zero or less, remove the products
		if(quantity <= 0) {
			if(curEntry != null)
				removeProduct(product);
			return;
		}
		
		// If a current cart entry doesn't exist, create one
		if(curEntry == null) {
			curEntry = new Shoppingcartentry(product, quantity);
			cartMap.put(product, curEntry);
			return;
		}
		
		// Update the quantity
		curEntry.setQuantity(quantity);
	}
	
	public static int getProductQuantity(Product product) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		if(curEntry != null)
			return curEntry.getQuantity();
		
		return 0;
	}
	
	public static void removeProduct(Product product) {
		cartMap.remove(product);
	}
	
	public static List<Product> getCartList() {
		List<Product> cartList = new Vector<Product>(cartMap.keySet().size());
		for(Product p : cartMap.keySet()) {
			cartList.add(p);
		}
		
		return cartList;
	}
	}



