package com.example.campus_catering;

import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	
	LoginDatabaseAdapter log;
	ImageView login;
	EditText regno;
	EditText pass;
	TextView forgot;
	TextView register;	
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getActionBar().setIcon(
        		   new ColorDrawable(getResources().getColor(android.R.color.transparent))); 
        
        login=(ImageView) findViewById(R.id.imageView1);
        regno=(EditText) findViewById(R.id.editText1);
        pass=(EditText) findViewById(R.id.editText2);
        forgot=(TextView) findViewById(R.id.textView4);
        register=(TextView) findViewById(R.id.textView3);
        
        log = new LoginDatabaseAdapter(getApplicationContext());
        log.open();
        
        register.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(MainActivity.this,Registration.class);
				startActivity(i);
			}
		});
			
		
        
        login.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String Password=pass.getText().toString();

				String storedPassword=log.getSinlgeEntry(Password);
				if(Password.equals(storedPassword))
				{
				
					Intent newi =new Intent(MainActivity.this,Lastpage.class);
					startActivity(newi);
				}
				else
					if(Password.equals("")){
						Toast.makeText(MainActivity.this, "Please Enter Your Password", Toast.LENGTH_LONG).show();
					}
					else
					{
						Toast.makeText(MainActivity.this, "Password Incorrect", Toast.LENGTH_LONG).show();
					}
			}
			
		});
        
        forgot.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				final Dialog dialog = new Dialog(MainActivity.this);
				dialog.getWindow();
				dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
				
				dialog.setContentView(R.layout.forgotscr);
				dialog.show();

				final  EditText security=(EditText)dialog.findViewById(R.id.editText1);
				final  TextView getpass=(TextView)dialog.findViewById(R.id.textView2);

				Button ok=(Button)dialog.findViewById(R.id.button1);
				Button cancel=(Button)dialog.findViewById(R.id.button2);

				ok.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						String userName=security.getText().toString();
						if(userName.equals(""))
						{
							Toast.makeText(getApplicationContext(), "Please enter your securityhint", Toast.LENGTH_SHORT).show();
						}
						else
						{
							String storedPassword=log.getAllTags(userName);
							if(storedPassword==null)
							{
								Toast.makeText(getApplicationContext(), "Please enter correct securityhint", Toast.LENGTH_SHORT).show();
							}else{
								Log.d("GET PASSWORD",storedPassword);
								getpass.setText(storedPassword);
							}
						}
			}
		});
       
				cancel.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			dialog.dismiss();
			
			
		}
	});
        
dialog.show();
			}
        });
    }

    
    @Override
	protected void onDestroy() {
		super.onDestroy();
		// Close The Database
		log.close();
	}

}
