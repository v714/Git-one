package com.example.campus_catering;
public class Shoppingcartentry {

	private Product mProduct;
	private int mQuantity;
	
	public Shoppingcartentry(Product product, int quantity) {
		mProduct = product;
		mQuantity = quantity;
	}
	
	public Product getProduct() {
		return mProduct;
	}
	
	public int getQuantity() {
		return mQuantity;
	}
	
	public void setQuantity(int quantity) {
		mQuantity = quantity;
	}

}
