package com.example.campus_catering;

import java.util.List;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ProductAdapterchaap extends BaseAdapter{

	private List<Product>  mproductlist;
	private LayoutInflater minflator;
	private boolean mShowquantity;
	
	public ProductAdapterchaap(List<Product> list, LayoutInflater inflator,boolean mshowQuantity)
	{
		mproductlist = list;
		minflator= inflator;
		mShowquantity = mshowQuantity;
		
	}
	
	@Override
	public int getCount() {
		return mproductlist.size();
	}

	@Override
	public Object getItem(int position) {
		return mproductlist.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		final ViewItem item;
		if (convertView==null)
		{
			convertView = minflator.inflate(R.layout.catalog,null);
			item = new ViewItem();
			item.productImageView = (ImageView) convertView.findViewById(R.id.ImageViewItem);
					
			item.productTitle = (TextView) convertView.findViewById(R.id.TextViewItem);
					
			item.productQuantity = (TextView) convertView.findViewById(R.id.textViewQuantity);
			convertView.setTag(item);	
		}
		
		else
		{
			
			item= (ViewItem) convertView.getTag();
			
		}
		
		Product cupro = mproductlist.get(position);
		
		item.productImageView.setImageDrawable(cupro.productImage);
		item.productTitle.setText(cupro.title);
		
		// Show the quantity in the cart or not
				if (mShowquantity) {
					item.productQuantity.setText("Quantity: "+ Carthelperchaap.getProductQuantity(cupro));
				} else {
					// Hid the view
					item.productQuantity.setVisibility(View.GONE);
				}

				return convertView;
			}
	private class ViewItem
	{
		ImageView productImageView;
		TextView productTitle;
		TextView productQuantity;
		
	}

}
