package com.example.campus_catering;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import android.content.res.Resources;

public class Carthelperdessert {

public static final String PRODUCT_INDEX = "PRODUCT_INDEX";
	
	private static List<Product> catalog;
	private static Map<Product, Shoppingcartentry> 
	cartMap = new HashMap<Product, Shoppingcartentry>();
	
	
	
	public static List<Product> getCatalog(Resources res) {
		
		if (catalog==null)
		{
			catalog = new Vector<Product>();
			catalog.add(new Product("Ice Cream Butterscotch Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Vanilla Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Chocolate Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Strawberry Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Pista Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Mango Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 25));
			
			catalog.add(new Product("Ice Cream Black Current Choco Dip",res.getDrawable(R.drawable.ice1), 
					"", 40));
			
			catalog.add(new Product("Brownie",res.getDrawable(R.drawable.dish1), 
					"", 35));
			
			catalog.add(new Product("Brownie with Ice Cream",res.getDrawable(R.drawable.dish1), 
					"", 45));
			
			catalog.add(new Product("Muffin",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Choco Pie",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Chocolate Roll",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Vanilla Roll",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Strawberry Roll",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Jam Roll",res.getDrawable(R.drawable.dish1), 
					"", 25));
			
			catalog.add(new Product("Melt Chocolates",res.getDrawable(R.drawable.dish1), 
					"", 20));
			
			
		}
		
		return catalog;
	}
	public static void setQuantity(Product product, int quantity) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		// If the quantity is zero or less, remove the products
		if(quantity <= 0) {
			if(curEntry != null)
				removeProduct(product);
			return;
		}
		
		// If a current cart entry doesn't exist, create one
		if(curEntry == null) {
			curEntry = new Shoppingcartentry(product, quantity);
			cartMap.put(product, curEntry);
			return;
		}
		
		// Update the quantity
		curEntry.setQuantity(quantity);
	}
	
	public static int getProductQuantity(Product product) {
		// Get the current cart entry
		Shoppingcartentry curEntry = cartMap.get(product);
		
		if(curEntry != null)
			return curEntry.getQuantity();
		
		return 0;
	}
	
	public static void removeProduct(Product product) {
		cartMap.remove(product);
	}
	
	public static List<Product> getCartList() {
		List<Product> cartList = new Vector<Product>(cartMap.keySet().size());
		for(Product p : cartMap.keySet()) {
			cartList.add(p);
		}
		
		return cartList;
	}
	}





