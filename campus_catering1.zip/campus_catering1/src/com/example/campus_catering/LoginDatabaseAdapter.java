package com.example.campus_catering;

import java.util.HashMap;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;


public class LoginDatabaseAdapter {
	
	
	static final String DATABASE_NAME = "Log.db";
	static final int DATABASE_VERSION = 1;
	public static final int NAME_COLUMN = 3;

	static final String DATABASE_CREATE = "create table "+"LOG"+"( " +"ID integer primary key autoincrement," + 
	"PASSWORD "+" text,"+"REPASSWORD text,"+ "SECURITYHINT text) ";

	public  SQLiteDatabase db;
	private final Context context;
	private DataBaseHelper dbHelper;
	
	public  LoginDatabaseAdapter (Context con)
	{
		context = con;
		dbHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);

	}
	public  LoginDatabaseAdapter open() throws SQLException 
	{
		db = dbHelper.getWritableDatabase();
		return this;
	}
	public void close() 
	{
		db.close();
	}

	public  SQLiteDatabase getDatabaseInstance()
	{
		return db;
	}
	
	public void insertEntry(String pas,String fpas,String phint)
	{
		ContentValues newValues = new ContentValues();
		newValues.put("PASSWORD", pas);
		newValues.put("REPASSWORD",fpas);
		newValues.put("SECURITYHINT",phint);

		db.insert("LOG", null, newValues);
	}

	public int deleteEntry(String password)
	{
		String where="PASSWORD=?";
		int numberOFEntriesDeleted= db.delete("LOG", where, new String[]{password}) ;
		return numberOFEntriesDeleted;
	}	
	
	public String getSinlgeEntry(String password)
	{
		Cursor cursor=db.query("LOG", null, " PASSWORD=?", new String[]{password}, null, null, null);
		if(cursor.getCount()<1) // UserName Not Exist
		{
			cursor.close();
			return "NOT EXIST";
		}
		cursor.moveToFirst();
		String fpas= cursor.getString(cursor.getColumnIndex("REPASSWORD"));
		cursor.close();
		return fpas;				
	}

	public String getAllTags(String a) {


		Cursor c = db.rawQuery("SELECT * FROM " + "LOG" + " where SECURITYHINT = '" +a + "'" , null);
		String str = null;
		if (c.moveToFirst()) {
			do {
				str = c.getString(c.getColumnIndex("PASSWORD"));
			} while (c.moveToNext());
		}
		return str;
	}
	public void  updateEntry(String pas,String fpas)
	{
		ContentValues updatedValues = new ContentValues();
		updatedValues.put("PASSWORD", pas);
		updatedValues.put("REPASSWORD",fpas);
		updatedValues.put("SECURITYHINT",fpas);

		String where="USERNAME = ?";
		db.update("LOG",updatedValues, where, new String[]{pas});			   
	}	

	public HashMap<String, String> getAnimalInfo(String id) {
		HashMap<String, String> wordList = new HashMap<String, String>();
		String selectQuery = "SELECT * FROM LOG where SECURITYHINT='"+id+"'";
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				wordList.put("PASSWORD", cursor.getString(1));
			} while (cursor.moveToNext());
		}				    
		return wordList;
	}	
	

}
