package com.example.campus_catering;

import java.util.List;

import com.example.campus_catering.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class Cartactivityfast extends Activity{

	private List<Product> mcartlist;
	private ProductAdapterfast mproductadap;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addremovefromcart);
		getActionBar().setIcon( new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		ImageView	b=(ImageView) findViewById(R.id.imageView1);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Intent i= new Intent (getBaseContext(),MainActivity.class);
			startActivity(i);
			}
		});
	
	mcartlist = Carthelperfast.getCartList();
	
	for(int i=0; i<mcartlist.size(); i++) 
	
	{
		mcartlist.get(i).selected = false;
	}
		
		final ListView l = (ListView) findViewById(R.id.menu_list);
		mproductadap = new ProductAdapterfast(mcartlist, getLayoutInflater(), true);
		l.setAdapter(mproductadap);
		l.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				
				Intent productDetailsIntent = new Intent(getBaseContext(),Itemdetailsfast.class);
				productDetailsIntent.putExtra(Carthelperfast.PRODUCT_INDEX, position);
				startActivity(productDetailsIntent);
			}
		});
	}
		
	
	
		@Override
		protected void onResume() {
			super.onResume();
			
			// Refresh the data
			if(mproductadap != null) {
				mproductadap.notifyDataSetChanged();
			}
			double subTotal = 0;
			  for(Product p : mcartlist) {
			   int quantity = Carthelperfast.getProductQuantity(p);
			   subTotal += p.price * quantity;
			  }
			   
			  TextView productPriceTextView = (TextView) findViewById(R.id.TextViewSubtotal);
			  productPriceTextView.setText("Subtotal: Rs" + subTotal);
		
	}
}



