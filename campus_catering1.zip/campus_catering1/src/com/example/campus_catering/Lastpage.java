package com.example.campus_catering;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class Lastpage extends Activity {

	private Category t;
	
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lastpage);
		
		ListView l;
		
		
		
		Button b=  (Button) findViewById(R.id.button2);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//finish();
				//System.exit(0);
				Intent intent = new Intent(Intent.ACTION_MAIN);
				intent.addCategory(Intent.CATEGORY_HOME);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		});
		

		
		SmsManager manager = SmsManager.getDefault();
				manager.sendTextMessage("+919592024839", null, "order received", null, null);
				Toast.makeText(getBaseContext(), "MEssage sent", Toast.LENGTH_LONG).show();
				
		//		catch (Exception e) {
					// TODO: handle exception
			//		Toast.makeText(getApplicationContext(), "Fail! Please Try Again", 
				//			Toast.LENGTH_LONG).show();
				//	e.printStackTrace();
			//	}
		
		
	}
	@Override
	public void onBackPressed() {
	    // do nothing.
	}
}
