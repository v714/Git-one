package com.example.campus_catering;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import android.content.res.Resources;

public class Carthelperfast {

public static final String PRODUCT_INDEX = "PRODUCT_INDEX";
	
	private static List<Product> catalog;
	private static Map<Product, Shoppingcartentry> 
	cartMap = new HashMap<Product, Shoppingcartentry>();
	
	
public static List<Product> getCatalog(Resources res) {
		
		if (catalog==null)
		{
			catalog = new Vector<Product>();
			
			catalog.add(new Product("Paneer Wrap",res.getDrawable(R.drawable.berg), 
					"", 35));
			
			catalog.add(new Product("Momos Veg",res.getDrawable(R.drawable.dish1), 
					"Momos filled with Fresh Veggies ", 30));
			
			catalog.add(new Product("Momos Special",res.getDrawable(R.drawable.dish1), 
					"Mix Ingredients Filled Momos ", 30));
			
			catalog.add(new Product("Mushroom Momos",res.getDrawable(R.drawable.dish1), 
					"Momos Filled with Fresh Mushroom ", 35));
			
			catalog.add(new Product("Paneer Momos",res.getDrawable(R.drawable.dish1), 
					"Momos Filled with Paneer", 40));
			
			catalog.add(new Product("(Fried) Momos Veg",res.getDrawable(R.drawable.dish1), 
					"Momos filled with Fresh Veggies  \n Rs 35", 35));
			
			catalog.add(new Product("(Fried) Momos Special",res.getDrawable(R.drawable.dish1), 
					"Mix Ingredients Filled Momos  \n Rs 35", 35));
			
			catalog.add(new Product("(Fried) Mushroom Momos",res.getDrawable(R.drawable.dish1), 
					"Momos Filled with Fresh Mushroom \n Rs 35", 40));
			
			catalog.add(new Product("(Fried) Paneer Momos",res.getDrawable(R.drawable.dish1), 
					"Momos Filled with Paneer \n Rs 35", 45));
			
			catalog.add(new Product("Grilled Burger",res.getDrawable(R.drawable.berg), 
					"Moist Grilled burger with seasonal toppings ", 25));
			
			catalog.add(new Product("Cheese Burger",res.getDrawable(R.drawable.berg), 
					"Potato filling with topped with slice of Cheese ", 35));
			
			catalog.add(new Product("Paneer Burger",res.getDrawable(R.drawable.berg), 
					"Burger filled with Paneer stuffing ", 30));
			
			catalog.add(new Product("Potatao Grilled Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Grilled Spicy Potato Sandwich ", 15));
			
			catalog.add(new Product("Veg Grilled Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Grilled sandwich with veggies filling ", 15));
			
			catalog.add(new Product("Grilled Pasta Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Cheese Pasta filling grilled Sandwich", 20));
			
			catalog.add(new Product("Paneer Korma Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Burger filled with Paneer stuffing ", 30));
			
			catalog.add(new Product("Chilly Garlic Paneer Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Burger filled with Paneer stuffing ", 30));
			
			catalog.add(new Product("Corn Delight Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Burger filled with Paneer stuffing ", 30));
			
			catalog.add(new Product("Pasta Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Burger filled with Paneer stuffing ", 30));
			
			catalog.add(new Product("Tripple Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Three Layers of Bread With filling", 30));
			
			catalog.add(new Product("Cheese Chilly Sandwich",res.getDrawable(R.drawable.sandwitch), 
					"Burger filled with Paneer stuffing", 25));
			
			catalog.add(new Product("Pizza Onion Caspicum",res.getDrawable(R.drawable.pizza), 
					"", 60));
			
			catalog.add(new Product("PineApple Pizza",res.getDrawable(R.drawable.pizza), 
					"", 65));
			
			catalog.add(new Product("Veg Pizza",res.getDrawable(R.drawable.pizza), 
					"", 60));
			
			catalog.add(new Product("Tomato Cheese Pizza",res.getDrawable(R.drawable.pizza), 
					"", 70));
			
			catalog.add(new Product("Mushroom Pizza",res.getDrawable(R.drawable.pizza), 
					"", 70));
			
			catalog.add(new Product("Country Special Pizza",res.getDrawable(R.drawable.pizza), 
					"", 80));
			
			catalog.add(new Product("Garlic Bread",res.getDrawable(R.drawable.berg), 
					"", 90));
			
			catalog.add(new Product("Crazy Wave Pizza",res.getDrawable(R.drawable.pizza), 
					"", 90));
			
			catalog.add(new Product("Mix Veg Pizza",res.getDrawable(R.drawable.pizza), 
					"", 85));
			
			catalog.add(new Product("Fully LOADED Pizza",res.getDrawable(R.drawable.pizza), 
					"", 80));
			
			catalog.add(new Product("Margarita Pizza",res.getDrawable(R.drawable.pizza), 
					"", 90));
			
			catalog.add(new Product("Red Sauce Pasta",res.getDrawable(R.drawable.berg), 
					"", 35));
			
			catalog.add(new Product("Masala Pasta",res.getDrawable(R.drawable.berg), 
					"", 35));
			
			catalog.add(new Product("White Sauce Pasta",res.getDrawable(R.drawable.berg), 
					"", 35));
			
			catalog.add(new Product("Italian Pasta",res.getDrawable(R.drawable.berg), 
					"", 25));
			
			
		}
		
		return catalog;
	}
public static void setQuantity(Product product, int quantity) {
	// Get the current cart entry
	Shoppingcartentry curEntry = cartMap.get(product);
	
	// If the quantity is zero or less, remove the products
	if(quantity <= 0) {
		if(curEntry != null)
			removeProduct(product);
		return;
	}
	
	// If a current cart entry doesn't exist, create one
	if(curEntry == null) {
		curEntry = new Shoppingcartentry(product, quantity);
		cartMap.put(product, curEntry);
		return;
	}
	
	// Update the quantity
	curEntry.setQuantity(quantity);
}

public static int getProductQuantity(Product product) {
	// Get the current cart entry
	Shoppingcartentry curEntry = cartMap.get(product);
	
	if(curEntry != null)
		return curEntry.getQuantity();
	
	return 0;
}

public static void removeProduct(Product product) {
	cartMap.remove(product);
}

public static List<Product> getCartList() {
	List<Product> cartList = new Vector<Product>(cartMap.keySet().size());
	for(Product p : cartMap.keySet()) {
		cartList.add(p);
	}
	
	return cartList;
}
}


