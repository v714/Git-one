/** Automatically generated file. DO NOT MODIFY */
package com.example.campus_catering;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}